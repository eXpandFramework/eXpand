Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports DevExpress.ExpressApp.Web
Imports Xpand.ExpressApp.Web
Imports DevExpress.ExpressApp
Imports DevExpress.ExpressApp.Security


Partial Public Class $projectsuffix$AspNetApplication
    Inherits XpandWebApplication
    Private module1 As DevExpress.ExpressApp.SystemModule.SystemModule
    Private module2 As DevExpress.ExpressApp.Web.SystemModule.SystemAspNetModule
    Private module3 As $projectsuffix$.Module.$projectsuffix$Module
    Private module4 As $projectsuffix$.Module.Web.$projectsuffix$AspNetModule
    Private module5 As DevExpress.ExpressApp.Validation.ValidationModule
    Private module6 As DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule
    Private securityModule1 As DevExpress.ExpressApp.Security.SecurityModule
    Friend WithEvents ViewVariantsModule1 As DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule
    Friend WithEvents XpandSystemModule1 As Xpand.ExpressApp.SystemModule.XpandSystemModule
    Friend WithEvents LogicModule1 As Xpand.ExpressApp.Logic.LogicModule
    Friend WithEvents XpandValidationModule1 As Xpand.ExpressApp.Validation.XpandValidationModule
    Friend WithEvents ConditionalControllerStateModule1 As Xpand.ExpressApp.ConditionalControllerState.ConditionalControllerStateModule
    Friend WithEvents ConditionalActionStateModule1 As Xpand.ExpressApp.ConditionalActionState.ConditionalActionStateModule
    Friend WithEvents ModelArtifactStateModule1 As Xpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule
    Friend WithEvents CloneObjectModule1 As DevExpress.ExpressApp.CloneObject.CloneObjectModule
    Friend WithEvents ModelDifferenceModule1 As Xpand.ExpressApp.ModelDifference.ModelDifferenceModule
    Friend WithEvents XpandSecurityModule1 As Xpand.ExpressApp.Security.XpandSecurityModule
    Friend WithEvents XpandViewVariantsModule1 As Xpand.ExpressApp.ViewVariants.XpandViewVariantsModule
    Friend WithEvents WorldCreatorModule1 As Xpand.ExpressApp.WorldCreator.WorldCreatorModule
    Friend WithEvents TreeListEditorsModuleBase1 As DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase
    Friend WithEvents IoModule1 As Xpand.ExpressApp.IO.IOModule
    Friend WithEvents PivotChartModuleBase1 As DevExpress.ExpressApp.PivotChart.PivotChartModuleBase
    Friend WithEvents XpandPivotChartModule1 As Xpand.ExpressApp.PivotChart.XpandPivotChartModule
    Friend WithEvents FilterDataStoreModule1 As Xpand.ExpressApp.FilterDataStore.FilterDataStoreModule
    Friend WithEvents AdditionalViewControlsModule1 As Xpand.ExpressApp.AdditionalViewControlsProvider.AdditionalViewControlsModule
    Friend WithEvents WorldCreatorSqlDBMapperModule1 As Xpand.ExpressApp.WorldCreator.SqlDBMapper.WorldCreatorSqlDBMapperModule
    Friend WithEvents ConditionalDetailViewModule1 As Xpand.ExpressApp.ConditionalDetailViews.ConditionalDetailViewModule
    Friend WithEvents XpandSystemAspNetModule1 As Xpand.ExpressApp.Web.SystemModule.XpandSystemAspNetModule
    Friend WithEvents AdditionalViewControlsProviderAspNetModule1 As Xpand.ExpressApp.AdditionalViewControlsProvider.Web.AdditionalViewControlsProviderAspNetModule
    Friend WithEvents ExceptionHandlingWebModule1 As Xpand.ExpressApp.ExceptionHandling.Web.ExceptionHandlingWebModule
    Friend WithEvents FilterDataStoreAspNetModule1 As Xpand.ExpressApp.FilterDataStore.Web.FilterDataStoreAspNetModule
    Friend WithEvents TreeListEditorsAspNetModule1 As DevExpress.ExpressApp.TreeListEditors.Web.TreeListEditorsAspNetModule
    Friend WithEvents IoAspNetModule1 As Xpand.ExpressApp.IO.Web.IOAspNetModule
    Friend WithEvents ModelDifferenceAspNetModule1 As Xpand.ExpressApp.ModelDifference.Web.ModelDifferenceAspNetModule
    Friend WithEvents NCarouselWebModule1 As Xpand.ExpressApp.NCarousel.Web.NCarouselWebModule
    Friend WithEvents PivotChartAspNetModule1 As DevExpress.ExpressApp.PivotChart.Web.PivotChartAspNetModule
    Friend WithEvents XpandPivotChartAspNetModule1 As Xpand.ExpressApp.PivotChart.Web.XpandPivotChartAspNetModule
    Friend WithEvents ThumbnailWebModule1 As Xpand.ExpressApp.Thumbnail.Web.ThumbnailWebModule
    Friend WithEvents XpandTreeListEditorsModule1 As Xpand.ExpressApp.TreeListEditors.XpandTreeListEditorsModule
    Friend WithEvents XpandTreeListEditorsAspNetModule1 As Xpand.ExpressApp.TreeListEditors.Web.XpandTreeListEditorsAspNetModule
    Friend WithEvents FileAttachmentsAspNetModule1 As DevExpress.ExpressApp.FileAttachments.Web.FileAttachmentsAspNetModule
    Friend WithEvents WorldCreatorWebModule1 As Xpand.ExpressApp.WorldCreator.Web.WorldCreatorWebModule
    Friend WithEvents SecurityComplex1 As DevExpress.ExpressApp.Security.SecurityComplex
    Friend WithEvents AuthenticationStandard1 As DevExpress.ExpressApp.Security.AuthenticationStandard

    Private sqlConnection1 As System.Data.SqlClient.SqlConnection

    Public Sub New()
        InitializeComponent()
        AddHandler LastLogonParametersReading, AddressOf winApplication_LastLogonParametersReading
    End Sub
    Private Sub winApplication_LastLogonParametersReading(ByVal sender As Object, ByVal e As LastLogonParametersReadingEventArgs)
        Dim logonParameters As AuthenticationStandardLogonParameters = TryCast(e.LogonObject, AuthenticationStandardLogonParameters)
        If logonParameters IsNot Nothing Then
            If String.IsNullOrEmpty(logonParameters.UserName) Then
                logonParameters.UserName = "Admin"
            End If
        End If
    End Sub
    Private Sub $projectsuffix$AspNetApplication_DatabaseVersionMismatch(ByVal sender As Object, ByVal e As DevExpress.ExpressApp.DatabaseVersionMismatchEventArgs) Handles MyBase.DatabaseVersionMismatch
#If EASYTEST Then
        e.Updater.Update()
        e.Handled = True
#Else
        If System.Diagnostics.Debugger.IsAttached Then
            e.Updater.Update()
            e.Handled = True
        Else
            Throw New InvalidOperationException( _
             "The application cannot connect to the specified database, because the latter doesn't exist or its version is older than that of the application." & Constants.vbCrLf & _
             "This error occurred  because the automatic database update was disabled when the application was started without debugging." & Constants.vbCrLf & _
             "To avoid this error, you should either start the application under Visual Studio in debug mode, or modify the " & _
             "source code of the 'DatabaseVersionMismatch' event handler to enable automatic database update, " & _
             "or manually create a database using the 'DBUpdater' tool." & Constants.vbCrLf & _
             "Anyway, refer to the 'Update Application and Database Versions' help topic at http://www.devexpress.com/Help/?document=ExpressApp/CustomDocument2795.htm " & _
             "for more detailed information. If this doesn't help, please contact our Support Team at http://www.devexpress.com/Support/Center/")
        End If
#End If
    End Sub

    Private Sub InitializeComponent()
        Me.module1 = New DevExpress.ExpressApp.SystemModule.SystemModule()
        Me.module2 = New DevExpress.ExpressApp.Web.SystemModule.SystemAspNetModule()
        Me.module3 = New $projectsuffix$.[Module].$projectsuffix$Module()
        Me.module4 = New $projectsuffix$.[Module].Web.$projectsuffix$AspNetModule()
        Me.module5 = New DevExpress.ExpressApp.Validation.ValidationModule()
        Me.module6 = New DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule()
        Me.securityModule1 = New DevExpress.ExpressApp.Security.SecurityModule()
        Me.sqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.ViewVariantsModule1 = New DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule()
        Me.XpandSystemModule1 = New Xpand.ExpressApp.SystemModule.XpandSystemModule()
        Me.LogicModule1 = New Xpand.ExpressApp.Logic.LogicModule()
        Me.XpandValidationModule1 = New Xpand.ExpressApp.Validation.XpandValidationModule()
        Me.ConditionalControllerStateModule1 = New Xpand.ExpressApp.ConditionalControllerState.ConditionalControllerStateModule()
        Me.ConditionalActionStateModule1 = New Xpand.ExpressApp.ConditionalActionState.ConditionalActionStateModule()
        Me.ModelArtifactStateModule1 = New Xpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule()
        Me.CloneObjectModule1 = New DevExpress.ExpressApp.CloneObject.CloneObjectModule()
        Me.ModelDifferenceModule1 = New Xpand.ExpressApp.ModelDifference.ModelDifferenceModule()
        Me.XpandSecurityModule1 = New Xpand.ExpressApp.Security.XpandSecurityModule()
        Me.XpandViewVariantsModule1 = New Xpand.ExpressApp.ViewVariants.XpandViewVariantsModule()
        Me.WorldCreatorModule1 = New Xpand.ExpressApp.WorldCreator.WorldCreatorModule()
        Me.TreeListEditorsModuleBase1 = New DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase()
        Me.IoModule1 = New Xpand.ExpressApp.IO.IOModule()
        Me.PivotChartModuleBase1 = New DevExpress.ExpressApp.PivotChart.PivotChartModuleBase()
        Me.XpandPivotChartModule1 = New Xpand.ExpressApp.PivotChart.XpandPivotChartModule()
        Me.FilterDataStoreModule1 = New Xpand.ExpressApp.FilterDataStore.FilterDataStoreModule()
        Me.AdditionalViewControlsModule1 = New Xpand.ExpressApp.AdditionalViewControlsProvider.AdditionalViewControlsModule()
        Me.WorldCreatorSqlDBMapperModule1 = New Xpand.ExpressApp.WorldCreator.SqlDBMapper.WorldCreatorSqlDBMapperModule()
        Me.ConditionalDetailViewModule1 = New Xpand.ExpressApp.ConditionalDetailViews.ConditionalDetailViewModule()
        Me.XpandSystemAspNetModule1 = New Xpand.ExpressApp.Web.SystemModule.XpandSystemAspNetModule()
        Me.AdditionalViewControlsProviderAspNetModule1 = New Xpand.ExpressApp.AdditionalViewControlsProvider.Web.AdditionalViewControlsProviderAspNetModule()
        Me.ExceptionHandlingWebModule1 = New Xpand.ExpressApp.ExceptionHandling.Web.ExceptionHandlingWebModule()
        Me.FilterDataStoreAspNetModule1 = New Xpand.ExpressApp.FilterDataStore.Web.FilterDataStoreAspNetModule()
        Me.TreeListEditorsAspNetModule1 = New DevExpress.ExpressApp.TreeListEditors.Web.TreeListEditorsAspNetModule()
        Me.IoAspNetModule1 = New Xpand.ExpressApp.IO.Web.IOAspNetModule()
        Me.ModelDifferenceAspNetModule1 = New Xpand.ExpressApp.ModelDifference.Web.ModelDifferenceAspNetModule()
        Me.NCarouselWebModule1 = New Xpand.ExpressApp.NCarousel.Web.NCarouselWebModule()
        Me.PivotChartAspNetModule1 = New DevExpress.ExpressApp.PivotChart.Web.PivotChartAspNetModule()
        Me.XpandPivotChartAspNetModule1 = New Xpand.ExpressApp.PivotChart.Web.XpandPivotChartAspNetModule()
        Me.ThumbnailWebModule1 = New Xpand.ExpressApp.Thumbnail.Web.ThumbnailWebModule()
        Me.XpandTreeListEditorsModule1 = New Xpand.ExpressApp.TreeListEditors.XpandTreeListEditorsModule()
        Me.XpandTreeListEditorsAspNetModule1 = New Xpand.ExpressApp.TreeListEditors.Web.XpandTreeListEditorsAspNetModule()
        Me.FileAttachmentsAspNetModule1 = New DevExpress.ExpressApp.FileAttachments.Web.FileAttachmentsAspNetModule()
        Me.WorldCreatorWebModule1 = New Xpand.ExpressApp.WorldCreator.Web.WorldCreatorWebModule()
        Me.SecurityComplex1 = New DevExpress.ExpressApp.Security.SecurityComplex()
        Me.AuthenticationStandard1 = New DevExpress.ExpressApp.Security.AuthenticationStandard()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'module5
        '
        Me.module5.AllowValidationDetailsAccess = True
        '
        'sqlConnection1
        '
        Me.sqlConnection1.ConnectionString = "Data Source=(local);Initial Catalog=$projectsuffix$;Integrated Security=SSPI;Pooling=f" & _
            "alse"
        Me.sqlConnection1.FireInfoMessageEventOnUserErrors = False
        '
        'ViewVariantsModule1
        '
        Me.ViewVariantsModule1.GenerateVariantsNode = True
        Me.ViewVariantsModule1.ShowAdditionalNavigation = False
        '
        'PivotChartModuleBase1
        '
        Me.PivotChartModuleBase1.ShowAdditionalNavigation = False
        '
        'SecurityComplex1
        '
        Me.SecurityComplex1.Authentication = Me.AuthenticationStandard1
        Me.SecurityComplex1.RoleType = GetType(DevExpress.Persistent.BaseImpl.Role)
        Me.SecurityComplex1.UserType = GetType(DevExpress.Persistent.BaseImpl.User)
        '
        'AuthenticationStandard1
        '
        Me.AuthenticationStandard1.LogonParametersType = GetType(Xpand.ExpressApp.Security.AuthenticationProviders.XpandLogonParameters)
        '
        '$projectsuffix$AspNetApplication
        '
        Me.ApplicationName = "$projectsuffix$"
        Me.Connection = Me.sqlConnection1
        Me.Modules.Add(Me.module1)
        Me.Modules.Add(Me.module2)
        Me.Modules.Add(Me.module6)
        Me.Modules.Add(Me.module5)
        Me.Modules.Add(Me.ViewVariantsModule1)
        Me.Modules.Add(Me.XpandSystemModule1)
        Me.Modules.Add(Me.LogicModule1)
        Me.Modules.Add(Me.XpandValidationModule1)
        Me.Modules.Add(Me.ConditionalControllerStateModule1)
        Me.Modules.Add(Me.ConditionalActionStateModule1)
        Me.Modules.Add(Me.ModelArtifactStateModule1)
        Me.Modules.Add(Me.CloneObjectModule1)
        Me.Modules.Add(Me.ModelDifferenceModule1)
        Me.Modules.Add(Me.securityModule1)
        Me.Modules.Add(Me.XpandSecurityModule1)
        Me.Modules.Add(Me.XpandViewVariantsModule1)
        Me.Modules.Add(Me.WorldCreatorModule1)
        Me.Modules.Add(Me.TreeListEditorsModuleBase1)
        Me.Modules.Add(Me.IoModule1)

        Me.Modules.Add(Me.PivotChartModuleBase1)
        Me.Modules.Add(Me.XpandPivotChartModule1)
        Me.Modules.Add(Me.FilterDataStoreModule1)
        Me.Modules.Add(Me.AdditionalViewControlsModule1)
        Me.Modules.Add(Me.WorldCreatorSqlDBMapperModule1)
        Me.Modules.Add(Me.ConditionalDetailViewModule1)
        Me.Modules.Add(Me.module3)
        Me.Modules.Add(Me.XpandSystemAspNetModule1)
        Me.Modules.Add(Me.AdditionalViewControlsProviderAspNetModule1)
        Me.Modules.Add(Me.ExceptionHandlingWebModule1)
        Me.Modules.Add(Me.FilterDataStoreAspNetModule1)
        Me.Modules.Add(Me.TreeListEditorsAspNetModule1)
        Me.Modules.Add(Me.IoAspNetModule1)
        Me.Modules.Add(Me.ModelDifferenceAspNetModule1)
        Me.Modules.Add(Me.NCarouselWebModule1)
        Me.Modules.Add(Me.PivotChartAspNetModule1)
        Me.Modules.Add(Me.XpandPivotChartAspNetModule1)
        Me.Modules.Add(Me.ThumbnailWebModule1)
        Me.Modules.Add(Me.XpandTreeListEditorsModule1)
        Me.Modules.Add(Me.XpandTreeListEditorsAspNetModule1)
        Me.Modules.Add(Me.FileAttachmentsAspNetModule1)
        Me.Modules.Add(Me.WorldCreatorWebModule1)
        Me.Modules.Add(Me.module4)
        Me.Security = Me.SecurityComplex1
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
End Class


