Imports Microsoft.VisualBasic
Imports System

Imports DevExpress.ExpressApp.Web
Imports DevExpress.ExpressApp.Web.Templates

Partial Public Class LoginPage
    Inherits BaseXafPage
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        WebApplication.Instance.CreateLogonControls(Me)
    End Sub
    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        MyBase.OnInit(e)
        ViewSiteControl = viewSiteControl1

    End Sub
    Protected Overrides Sub OnViewChanged(ByVal view As DevExpress.ExpressApp.View)
        ViewSiteControl = viewSiteControl1
        MyBase.OnViewChanged(view)
    End Sub
End Class
