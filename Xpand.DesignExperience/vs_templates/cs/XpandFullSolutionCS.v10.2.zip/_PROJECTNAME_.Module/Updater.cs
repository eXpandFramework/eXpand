using System;
using DevExpress.Xpo;
using DevExpress.ExpressApp;

namespace $safesolutionname$.Module
{
    public class Updater : Xpand.Persistent.BaseImpl.Updater
    {
        public Updater(ObjectSpace objectSpace, Version currentDBVersion)
            : base(objectSpace, currentDBVersion) {
        }
        public override void UpdateDatabaseAfterUpdateSchema()
        {
            base.UpdateDatabaseAfterUpdateSchema();
            InitializeSecurity();
        }

    }
}
