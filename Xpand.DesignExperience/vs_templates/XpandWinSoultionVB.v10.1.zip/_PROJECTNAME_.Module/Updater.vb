Imports System
Imports DevExpress.Xpo


Public Class Updater
    Inherits Xpand.Persistent.BaseImpl.Updater

	Public Sub New(ByVal session As Session, ByVal currentDBVersion As Version)
		MyBase.New(session, currentDBVersion)
	End Sub

	Public Overrides Sub UpdateDatabaseAfterUpdateSchema()
        MyBase.UpdateDatabaseAfterUpdateSchema()
        InitializeSecurity()
	End Sub

End Class
