using System;
using System.Linq;
using DevExpress.ExpressApp;
using System.Collections.Generic;

namespace Xpand.Dashboard.Web
{
    public sealed partial class XpandDashboardWebModule : ModuleBase
    { // http://documentation.devexpress.com/#Xaf/clsDevExpressExpressAppModuleBasetopic
        public XpandDashboardWebModule()
        {
            InitializeComponent();
        }
    }
}
