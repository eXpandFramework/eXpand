﻿using DevExpress.DashboardWeb;
using DevExpress.ExpressApp;
using DevExpress.ExpressApp.Editors;
using DevExpress.ExpressApp.Model;
using DevExpress.ExpressApp.Web.Editors;
using System;
using System.Collections.Generic;
using System.Linq;
using Xpand.ExpressApp.Dashboard.BusinessObjects;

namespace Xpand.Dashboard.Web.PropertyEditors
{
    [PropertyEditor(typeof(String), false)]
    public class DashboardViewEditorWeb : WebPropertyEditor, IComplexViewItem
    {
        ASPxDashboardViewer _ASPxDashboardViewer;
        XafApplication _Application;
        IObjectSpace _ObjectSpace;

        public DashboardViewEditorWeb(Type objectType, IModelMemberViewItem model) : base(objectType, model) { }

        public void Setup(IObjectSpace objectSpace, XafApplication application)
        {
            _ObjectSpace = objectSpace;
            _Application = application;
        }

        protected override System.Web.UI.WebControls.WebControl CreateViewModeControlCore()
        {
            //if (_ASPxDashboardViewer == null)
            _ASPxDashboardViewer = CreateDashboardViewer();
            return _ASPxDashboardViewer;
        }

        protected override System.Web.UI.WebControls.WebControl CreateEditModeControlCore()
        {
            //if (_ASPxDashboardViewer == null)
            _ASPxDashboardViewer = CreateDashboardViewer();
            return _ASPxDashboardViewer;
        }

        protected override void ReadEditModeValueCore() { }

        protected override object GetControlValueCore()
        {
            return null;
        }

        private ASPxDashboardViewer CreateDashboardViewer()
        {
            var control = new ASPxDashboardViewer() { DashboardId = Definition.Name, RegisterJQuery = true };
            control.DashboardLoading += DashboardLoading;
            control.DataLoading += DataLoading;
            return control;
        }

        public override void BreakLinksToControl(bool unwireEventsOnly)
        {
            if (_ASPxDashboardViewer != null && unwireEventsOnly)
            {
                _ASPxDashboardViewer.DashboardLoading -= DashboardLoading;
                _ASPxDashboardViewer.DataLoading -= DataLoading;
            }
            base.BreakLinksToControl(unwireEventsOnly);
        }

        void DashboardLoading(object sender, DashboardLoadingEventArgs e)
        {
            var template = CurrentObject as IDashboardDefinition;
            e.DashboardXml = template.Xml;
        }

        void DataLoading(object sender, DataLoadingWebEventArgs e)
        {
            if (e.Data == null)
            {
                var dsType = Definition.DashboardTypes.First(t => t.Caption == e.DataSourceName).Type;
                e.Data = _ObjectSpace.GetObjects(dsType);
            }
        }

        IDashboardDefinition Definition
        {
            get { return CurrentObject as IDashboardDefinition; }
        }

        public ASPxDashboardViewer DashboardViewer
        {
            get { return (ASPxDashboardViewer)Control; }
        }

        public IObjectSpace ObjectSpace
        {
            get { return _ObjectSpace; }
        }

        public XafApplication Application
        {
            get { return _Application; }
        }
    }
}
