using System;
using DevExpress.ExpressApp.Security;
using DevExpress.ExpressApp.Updating;
using DevExpress.Xpo;
using DevExpress.Data.Filtering;
using DevExpress.Persistent.BaseImpl;
using eXpand.ExpressApp.MemberLevelSecurity;

namespace Solution1.Module
{
    public class Updater : ModuleUpdater
    {
        public Updater(Session session, Version currentDBVersion) : base(session, currentDBVersion) { }
        public override void UpdateDatabaseAfterUpdateSchema()
        {
            base.UpdateDatabaseAfterUpdateSchema();
            InitializeSecurity();
        }

        private void InitializeSecurity()
        {
            User admin = EnsureUserExists("admin", "Administrator");
            User user = EnsureUserExists("user", "User");

            Role admins = EnsureRoleExists("Administrators");
            Role users = EnsureRoleExists("Users");

            ApplyDenySecurityAccessPermissions(users);
            ApplyModelEditingPermission(admins);
            ApplyMemberLevelSecurity(admins, users);
            admin.Roles.Add(admins);
            user.Roles.Add(users);

            admin.Save();
            user.Save();
        }

        private User EnsureUserExists(string userName, string firstName)
        {
            var user = Session.FindObject<User>(new BinaryOperator("UserName", userName));
            if (user == null)
            {
                user = new User(Session) { UserName = userName, FirstName = firstName };
                user.SetPassword("");
                user.Save();
            }
            return user;
        }

        private Role EnsureRoleExists(string roleName)
        {
            var role = Session.FindObject<Role>(new BinaryOperator("Name", roleName));
            if (role == null)
            {
                role = new Role(Session) { Name = roleName };

                while (role.PersistentPermissions.Count > 0)
                {
                    Session.Delete(role.PersistentPermissions[0]);
                }
                ApplyDefaultPermissions(role);
                role.Save();
            }

            return role;
        }


        private static void ApplyDefaultPermissions(RoleBase role)
        {
            role.AddPermission(new ObjectAccessPermission(typeof(object), ObjectAccess.AllAccess));
            role.Save();
        }

        void ApplyMemberLevelSecurity(params Role[] roles)
        {
            foreach (var role in roles) {
                role.AddPermission(new MemberAccessPermission(typeof(object), null, MemberOperation.Read,
                                                          ObjectAccessModifier.Allow));
                role.AddPermission(new MemberAccessPermission(typeof(object), null, MemberOperation.Write,
                                                              ObjectAccessModifier.Allow));
                role.Save();
            }
        }

        private static void ApplyModelEditingPermission(RoleBase role)
        {
            role.AddPermission(new EditModelPermission(ModelAccessModifier.Allow));
            role.Save();
        }

        private static void ApplyDenySecurityAccessPermissions(RoleBase role)
        {
            role.AddPermission(new ObjectAccessPermission(typeof(Role), ObjectAccess.AllAccess,
                                                          ObjectAccessModifier.Deny));
            role.Save();
        }
    }
}
