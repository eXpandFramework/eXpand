using System;
using System.Collections.Generic;
using System.ComponentModel;
using DevExpress.ExpressApp.Web;
using eXpand.ExpressApp.Web;

namespace $safesolutionname$.Web {
	public partial class $projectsuffix$AspNetApplication : WebComponent {
		private DevExpress.ExpressApp.SystemModule.SystemModule module1;
		private DevExpress.ExpressApp.Web.SystemModule.SystemAspNetModule module2;
		private $safesolutionname$.Module.$projectsuffix$Module module3;
		private $safesolutionname$.Module.Web.$projectsuffix$AspNetModule module4;
		private DevExpress.ExpressApp.Security.SecurityModule securityModule1;
        private DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule module6;
        private System.Data.SqlClient.SqlConnection sqlConnection1;
        private DevExpress.ExpressApp.AuditTrail.AuditTrailModule auditTrailModule1;
        private DevExpress.ExpressApp.CloneObject.CloneObjectModule cloneObjectModule1;
        private DevExpress.ExpressApp.ConditionalFormatting.ConditionalFormattingModule conditionalFormattingModule1;
        private DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule viewVariantsModule1;
        private eXpand.ExpressApp.SystemModule.eXpandSystemModule eXpandSystemModule1;
        private eXpand.ExpressApp.Security.eXpandSecurityModule eXpandSecurityModule1;
        private eXpand.ExpressApp.Validation.eXpandValidationModule eXpandValidationModule1;
        private eXpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule modelArtifactStateModule1;
        private eXpand.ExpressApp.ModelDifference.ModelDifferenceModule modelDifferenceModule1;
        private eXpand.ExpressApp.ViewVariants.eXpandViewVariantsModule eXpandViewVariantsModule1;
        private DevExpress.ExpressApp.ConditionalEditorState.ConditionalEditorStateModuleBase conditionalEditorStateModuleBase1;
        private eXpand.ExpressApp.WorldCreator.WorldCreatorModule worldCreatorModule1;
        private DevExpress.ExpressApp.Security.SecurityComplex securityComplex1;
        private DevExpress.ExpressApp.Security.AuthenticationStandard authenticationStandard1;
        private DevExpress.ExpressApp.FileAttachments.Web.FileAttachmentsAspNetModule fileAttachmentsAspNetModule1;
        private DevExpress.ExpressApp.HtmlPropertyEditor.Web.HtmlPropertyEditorAspNetModule htmlPropertyEditorAspNetModule1;
        private DevExpress.ExpressApp.PivotChart.PivotChartModuleBase pivotChartModuleBase1;
        private DevExpress.ExpressApp.PivotChart.Web.PivotChartAspNetModule pivotChartAspNetModule1;
        private DevExpress.ExpressApp.Reports.Web.ReportsAspNetModule reportsAspNetModule1;
        private DevExpress.ExpressApp.Scheduler.SchedulerModuleBase schedulerModuleBase1;
        private DevExpress.ExpressApp.Scheduler.Web.SchedulerAspNetModule schedulerAspNetModule1;
        private DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase treeListEditorsModuleBase1;
        private DevExpress.ExpressApp.TreeListEditors.Web.TreeListEditorsAspNetModule treeListEditorsAspNetModule1;
        private eXpand.ExpressApp.ModelDifference.Web.ModelDifferenceAspNetModule modelDifferenceAspNetModule1;
        private eXpand.ExpressApp.Web.SystemModule.eXpandSystemAspNetModule eXpandSystemAspNetModule1;
        private DevExpress.ExpressApp.ConditionalEditorState.Web.ConditionalEditorStateAspNetModule conditionalEditorStateAspNetModule1;
        private eXpand.ExpressApp.WorldCreator.Web.WorldCreatorWebModule worldCreatorWebModule1;
        private DevExpress.ExpressApp.Validation.ValidationModule module5;
	
		public $projectsuffix$AspNetApplication() {
			InitializeComponent();
		}

		private void $projectsuffix$AspNetApplication_DatabaseVersionMismatch(object sender, DevExpress.ExpressApp.DatabaseVersionMismatchEventArgs e) {
#if EASYTEST
			e.Updater.Update();
			e.Handled = true;
#else
			if(System.Diagnostics.Debugger.IsAttached) {
				e.Updater.Update();
				e.Handled = true;
			}
			else {
				throw new InvalidOperationException(
					"The application cannot connect to the specified database, because the latter doesn't exist or its version is older than that of the application.\r\n" +
					"The automatic update is disabled, because the application was started without debugging.\r\n" +
					"You should start the application under Visual Studio, or modify the " + 
					"source code of the 'DatabaseVersionMismatch' event handler to enable automatic database update, " + 
					"or manually create a database using the 'DBUpdater' tool.");
			}
#endif
		}

		private void InitializeComponent() {
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof($projectsuffix$AspNetApplication));
			this.module1 = new DevExpress.ExpressApp.SystemModule.SystemModule();
			this.module2 = new DevExpress.ExpressApp.Web.SystemModule.SystemAspNetModule();
            this.module5 = new DevExpress.ExpressApp.Validation.ValidationModule();
            this.module6 = new DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule();
            this.securityModule1 = new DevExpress.ExpressApp.Security.SecurityModule();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.auditTrailModule1 = new DevExpress.ExpressApp.AuditTrail.AuditTrailModule();
            this.cloneObjectModule1 = new DevExpress.ExpressApp.CloneObject.CloneObjectModule();
            this.conditionalFormattingModule1 = new DevExpress.ExpressApp.ConditionalFormatting.ConditionalFormattingModule();
            this.viewVariantsModule1 = new DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule();
            this.eXpandSystemModule1 = new eXpand.ExpressApp.SystemModule.eXpandSystemModule();
            this.eXpandSecurityModule1 = new eXpand.ExpressApp.Security.eXpandSecurityModule();
            this.eXpandValidationModule1 = new eXpand.ExpressApp.Validation.eXpandValidationModule();
            this.modelArtifactStateModule1 = new eXpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule();
            this.modelDifferenceModule1 = new eXpand.ExpressApp.ModelDifference.ModelDifferenceModule();
            this.eXpandViewVariantsModule1 = new eXpand.ExpressApp.ViewVariants.eXpandViewVariantsModule();
            this.conditionalEditorStateModuleBase1 = new DevExpress.ExpressApp.ConditionalEditorState.ConditionalEditorStateModuleBase();
            this.worldCreatorModule1 = new eXpand.ExpressApp.WorldCreator.WorldCreatorModule();
            this.securityComplex1 = new DevExpress.ExpressApp.Security.SecurityComplex();
            this.authenticationStandard1 = new DevExpress.ExpressApp.Security.AuthenticationStandard();
            this.fileAttachmentsAspNetModule1 = new DevExpress.ExpressApp.FileAttachments.Web.FileAttachmentsAspNetModule();
            this.htmlPropertyEditorAspNetModule1 = new DevExpress.ExpressApp.HtmlPropertyEditor.Web.HtmlPropertyEditorAspNetModule();
            this.pivotChartModuleBase1 = new DevExpress.ExpressApp.PivotChart.PivotChartModuleBase();
            this.pivotChartAspNetModule1 = new DevExpress.ExpressApp.PivotChart.Web.PivotChartAspNetModule();
            this.reportsAspNetModule1 = new DevExpress.ExpressApp.Reports.Web.ReportsAspNetModule();
            this.schedulerModuleBase1 = new DevExpress.ExpressApp.Scheduler.SchedulerModuleBase();
            this.schedulerAspNetModule1 = new DevExpress.ExpressApp.Scheduler.Web.SchedulerAspNetModule();
            this.treeListEditorsModuleBase1 = new DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase();
            this.treeListEditorsAspNetModule1 = new DevExpress.ExpressApp.TreeListEditors.Web.TreeListEditorsAspNetModule();
            this.modelDifferenceAspNetModule1 = new eXpand.ExpressApp.ModelDifference.Web.ModelDifferenceAspNetModule();
            this.eXpandSystemAspNetModule1 = new eXpand.ExpressApp.Web.SystemModule.eXpandSystemAspNetModule();
            this.conditionalEditorStateAspNetModule1 = new DevExpress.ExpressApp.ConditionalEditorState.Web.ConditionalEditorStateAspNetModule();
            this.worldCreatorWebModule1 = new eXpand.ExpressApp.WorldCreator.Web.WorldCreatorWebModule();
			this.module3 = new $safesolutionname$.Module.$projectsuffix$Module();
			this.module4 = new $safesolutionname$.Module.Web.$projectsuffix$AspNetModule();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
// 
            // module1
            // 
            this.module1.AdditionalBusinessClasses.Add(typeof(DevExpress.Xpo.XPObjectType));
            // 
            // module5
            // 
            this.module5.AllowValidationDetailsAccess = true;
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=(local);Initial Catalog=$safesolutionname$;Integrated Security=SSPI;Pooling=false";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // auditTrailModule1
            // 
            this.auditTrailModule1.AdditionalBusinessClasses.Add(typeof(DevExpress.Persistent.BaseImpl.AuditDataItemPersistent));
            this.auditTrailModule1.AuditDataItemPersistentType = typeof(DevExpress.Persistent.BaseImpl.AuditDataItemPersistent);
            // 
            // viewVariantsModule1
            // 
            this.viewVariantsModule1.ShowAdditionalNavigation = false;
            // 
            // securityComplex1
            // 
            this.securityComplex1.Authentication = this.authenticationStandard1;
            this.securityComplex1.IsGrantedForNonExistentPermission = false;
            this.securityComplex1.RoleType = typeof(DevExpress.Persistent.BaseImpl.Role);
            this.securityComplex1.UserType = typeof(DevExpress.Persistent.BaseImpl.User);
            // 
            // authenticationStandard1
            // 
            this.authenticationStandard1.LogonParametersType = typeof(DevExpress.ExpressApp.Security.AuthenticationStandardLogonParameters);
            // 
            // htmlPropertyEditorAspNetModule1
            // 
            this.htmlPropertyEditorAspNetModule1.Description = "Contains the Property Editor which allows end-users to format string properties\' " +
                "values using Hyper Text Markup Language (HTML).";
            this.htmlPropertyEditorAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.SystemModule.SystemModule));
            // 
            // pivotChartModuleBase1
            // 
            this.pivotChartModuleBase1.ShowAdditionalNavigation = false;
            // 
            // pivotChartAspNetModule1
            // 
            this.pivotChartAspNetModule1.Description = "Provides the capability to analyze data via the ASPxPivotGrid and XtraCharts cont" +
                "rols. Works with the Business Class Library\'s analysis-specific data types.";
            this.pivotChartAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.SystemModule.SystemModule));
            this.pivotChartAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.PivotChart.PivotChartModuleBase));
            // 
            // reportsAspNetModule1
            // 
            this.reportsAspNetModule1.Description = resources.GetString("reportsAspNetModule1.Description");
            this.reportsAspNetModule1.EnableInplaceReports = true;
            this.reportsAspNetModule1.ReportDataType = typeof(DevExpress.ExpressApp.Reports.ReportData);
            this.reportsAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.SystemModule.SystemModule));
            this.reportsAspNetModule1.ShowAdditionalNavigation = false;
            // 
            // schedulerAspNetModule1
            // 
            this.schedulerAspNetModule1.Description = "Uses the ASPxScheduler controls suite to display DevExpress.Persistent.Base.IEvent objects in Web XAF applications.";
            this.schedulerAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.SystemModule.SystemModule));
            this.schedulerAspNetModule1.RequiredModuleTypes.Add(typeof(DevExpress.ExpressApp.Scheduler.SchedulerModuleBase));
            // 
            // module3
            // 
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.CodeTemplate));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.CodeTemplateInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedCollectionMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedCoreTypeMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedReferenceMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentMapInheritanceAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentAggregatedAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentAssociationAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentCollectionMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentCoreTypeMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentCustomAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentDefaultClassOptionsAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentReferenceMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentSizeAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentValueConverter));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAssemblyInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentClassInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.InterfaceInfo));
            
			// 
			// $projectsuffix$AspNetApplication
			// 
			this.ApplicationName = "$solutionname$";
			this.Connection = this.sqlConnection1;
            this.Modules.Add(this.module1);
            this.Modules.Add(this.module2);
            this.Modules.Add(this.module6);
            this.Modules.Add(this.auditTrailModule1);
            this.Modules.Add(this.cloneObjectModule1);
            this.Modules.Add(this.conditionalFormattingModule1);
            this.Modules.Add(this.module5);
            this.Modules.Add(this.viewVariantsModule1);
            this.Modules.Add(this.eXpandSystemModule1);
            this.Modules.Add(this.eXpandSecurityModule1);
            this.Modules.Add(this.eXpandValidationModule1);
            this.Modules.Add(this.modelArtifactStateModule1);
            this.Modules.Add(this.modelDifferenceModule1);
            this.Modules.Add(this.eXpandViewVariantsModule1);
            this.Modules.Add(this.conditionalEditorStateModuleBase1);
            this.Modules.Add(this.worldCreatorModule1);
            this.Modules.Add(this.module3);
            this.Modules.Add(this.fileAttachmentsAspNetModule1);
            this.Modules.Add(this.htmlPropertyEditorAspNetModule1);
            this.Modules.Add(this.pivotChartModuleBase1);
            this.Modules.Add(this.pivotChartAspNetModule1);
            this.Modules.Add(this.reportsAspNetModule1);
            this.Modules.Add(this.schedulerModuleBase1);
            this.Modules.Add(this.schedulerAspNetModule1);
            this.Modules.Add(this.treeListEditorsModuleBase1);
            this.Modules.Add(this.treeListEditorsAspNetModule1);
            this.Modules.Add(this.modelDifferenceAspNetModule1);
            this.Modules.Add(this.eXpandSystemAspNetModule1);
            this.Modules.Add(this.conditionalEditorStateAspNetModule1);
            this.Modules.Add(this.worldCreatorWebModule1);
            this.Modules.Add(this.module4);
            this.Modules.Add(this.securityModule1);
            this.Security = this.securityComplex1;
			this.DatabaseVersionMismatch += new System.EventHandler<DevExpress.ExpressApp.DatabaseVersionMismatchEventArgs>(this.$projectsuffix$AspNetApplication_DatabaseVersionMismatch);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
	}
}
