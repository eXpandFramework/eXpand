using eXpand.ExpressApp.FilterDataStore.Win;

namespace $safesolutionname$.Win
{
    partial class $safesolutionname$WindowsFormsApplication
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.module1 = new DevExpress.ExpressApp.SystemModule.SystemModule();
            this.module2 = new DevExpress.ExpressApp.Win.SystemModule.SystemWindowsFormsModule();
            this.module3 = new $safesolutionname$.Module.$safesolutionname$Module();
            this.module4 = new $safesolutionname$.Module.Win.$safesolutionname$WindowsFormsModule();
            this.module5 = new DevExpress.ExpressApp.Validation.ValidationModule();
            this.module6 = new DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule();
            this.module7 = new DevExpress.ExpressApp.Validation.Win.ValidationWindowsFormsModule();
            this.securityModule1 = new DevExpress.ExpressApp.Security.SecurityModule();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.auditTrailModule1 = new DevExpress.ExpressApp.AuditTrail.AuditTrailModule();
            this.cloneObjectModule1 = new DevExpress.ExpressApp.CloneObject.CloneObjectModule();
            this.conditionalFormattingModule1 = new DevExpress.ExpressApp.ConditionalFormatting.ConditionalFormattingModule();
            this.viewVariantsModule1 = new DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule();
            this.eXpandSystemModule1 = new eXpand.ExpressApp.SystemModule.eXpandSystemModule();
            this.eXpandSecurityModule1 = new eXpand.ExpressApp.Security.eXpandSecurityModule();
            this.eXpandValidationModule1 = new eXpand.ExpressApp.Validation.eXpandValidationModule();
            this.modelArtifactStateModule1 = new eXpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule();
            this.modelDifferenceModule1 = new eXpand.ExpressApp.ModelDifference.ModelDifferenceModule();
            this.eXpandViewVariantsModule1 = new eXpand.ExpressApp.ViewVariants.eXpandViewVariantsModule();
            this.conditionalEditorStateModuleBase1 = new DevExpress.ExpressApp.ConditionalEditorState.ConditionalEditorStateModuleBase();
            this.worldCreatorModule1 = new eXpand.ExpressApp.WorldCreator.WorldCreatorModule();
            this.ioModule1 = new eXpand.ExpressApp.IO.IOModule();
            this.conditionalEditorStateWindowsFormsModule1 = new DevExpress.ExpressApp.ConditionalEditorState.Win.ConditionalEditorStateWindowsFormsModule();
            this.fileAttachmentsWindowsFormsModule1 = new DevExpress.ExpressApp.FileAttachments.Win.FileAttachmentsWindowsFormsModule();
            this.htmlPropertyEditorWindowsFormsModule1 = new DevExpress.ExpressApp.HtmlPropertyEditor.Win.HtmlPropertyEditorWindowsFormsModule();
            this.pivotChartModuleBase1 = new DevExpress.ExpressApp.PivotChart.PivotChartModuleBase();
            this.pivotChartWindowsFormsModule1 = new DevExpress.ExpressApp.PivotChart.Win.PivotChartWindowsFormsModule();
            this.printingWindowsFormsModule1 = new DevExpress.ExpressApp.Printing.Win.PrintingWindowsFormsModule();
            this.reportsWindowsFormsModule1 = new DevExpress.ExpressApp.Reports.Win.ReportsWindowsFormsModule();
            _filterDataStoreWindowsFormsModule=new FilterDataStoreWindowsFormsModule();
            this.schedulerModuleBase1 = new DevExpress.ExpressApp.Scheduler.SchedulerModuleBase();
            this.schedulerWindowsFormsModule1 = new DevExpress.ExpressApp.Scheduler.Win.SchedulerWindowsFormsModule();
            this.treeListEditorsModuleBase1 = new DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase();
            this.treeListEditorsWindowsFormsModule1 = new DevExpress.ExpressApp.TreeListEditors.Win.TreeListEditorsWindowsFormsModule();
            this.eXpandSystemWindowsFormsModule1 = new eXpand.ExpressApp.Win.SystemModule.eXpandSystemWindowsFormsModule();
            this.modelArtifactStateWindowsFormsModule1 = new eXpand.ExpressApp.ModelArtifactState.Win.ModelArtifactStateWindowsFormsModule();
            this.modelDifferenceWindowsFormsModule1 = new eXpand.ExpressApp.ModelDifference.Win.ModelDifferenceWindowsFormsModule();
            this.eXpandTreeListEditorsWin1 = new eXpand.ExpressApp.TreeListEditors.Win.eXpandTreeListEditorsWin();
            this.eXpandViewVariantsWin1 = new eXpand.ExpressApp.ViewVariants.Win.eXpandViewVariantsWin();
            this.wizardUIWindowsFormsModule1 = new eXpand.ExpressApp.WizardUI.Win.WizardUIWindowsFormsModule();
            this.worldCreatorWinModule1 = new eXpand.ExpressApp.WorldCreator.Win.WorldCreatorWinModule();
            this.ioWinModule1 = new eXpand.ExpressApp.IO.Win.IOWinModule();
            this.securityComplex1 = new DevExpress.ExpressApp.Security.SecurityComplex();
            this.authenticationStandard1 = new DevExpress.ExpressApp.Security.AuthenticationStandard();

            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // module1
            // 
            this.module1.AdditionalBusinessClasses.Add(typeof(DevExpress.Xpo.XPObjectType));
            // 
            // module3
            // 
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.CodeTemplate));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.CodeTemplateInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedCollectionMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedCoreTypeMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.ExtendedReferenceMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentMapInheritanceAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentAggregatedAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentAssociationAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentCollectionMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentCoreTypeMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentCustomAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentDefaultClassOptionsAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentReferenceMemberInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentSizeAttribute));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAttributeInfos.PersistentValueConverter));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentAssemblyInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.PersistentClassInfo));
            this.module3.AdditionalBusinessClasses.Add(typeof(eXpand.Persistent.BaseImpl.PersistentMetaData.InterfaceInfo));
            // 
            // module5
            // 
            this.module5.AllowValidationDetailsAccess = true;
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=(local);Initial Catalog=$safesolutionname$;Integrated Security=SSPI;Pooling=false";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // auditTrailModule1
            // 
            this.auditTrailModule1.AdditionalBusinessClasses.Add(typeof(DevExpress.Persistent.BaseImpl.AuditDataItemPersistent));
            this.auditTrailModule1.AuditDataItemPersistentType = typeof(DevExpress.Persistent.BaseImpl.AuditDataItemPersistent);
            // 
            // viewVariantsModule1
            // 
            this.viewVariantsModule1.ShowAdditionalNavigation = false;
            // 
            // pivotChartModuleBase1
            // 
            this.pivotChartModuleBase1.ShowAdditionalNavigation = false;
            // 
            // reportsWindowsFormsModule1
            // 
            this.reportsWindowsFormsModule1.EnableInplaceReports = true;
            this.reportsWindowsFormsModule1.ReportDataType = typeof(DevExpress.ExpressApp.Reports.ReportData);
            this.reportsWindowsFormsModule1.ShowAdditionalNavigation = false;
            // 
            // securityComplex1
            // 
            this.securityComplex1.Authentication = this.authenticationStandard1;
            this.securityComplex1.IsGrantedForNonExistentPermission = false;
            this.securityComplex1.RoleType = typeof(DevExpress.Persistent.BaseImpl.Role);
            this.securityComplex1.UserType = typeof(DevExpress.Persistent.BaseImpl.User);
            // 
            // authenticationStandard1
            // 
            this.authenticationStandard1.LogonParametersType = typeof(DevExpress.ExpressApp.Security.AuthenticationStandardLogonParameters);
            // 
            // $safesolutionname$WindowsFormsApplication
            // 
            this.ApplicationName = "$safesolutionname$";
            this.Connection = this.sqlConnection1;
            this.Modules.Add(this.module1);
            this.Modules.Add(this.module2);
            this.Modules.Add(this.module6);
            this.Modules.Add(this.auditTrailModule1);
            this.Modules.Add(this.cloneObjectModule1);
            this.Modules.Add(this.conditionalFormattingModule1);
            this.Modules.Add(this.module5);
            this.Modules.Add(this.viewVariantsModule1);
            this.Modules.Add(this.eXpandSystemModule1);
            this.Modules.Add(this.eXpandSecurityModule1);
            this.Modules.Add(this.eXpandValidationModule1);
            this.Modules.Add(this.modelArtifactStateModule1);
            this.Modules.Add(this.modelDifferenceModule1);
            this.Modules.Add(this.eXpandViewVariantsModule1);
            this.Modules.Add(this.conditionalEditorStateModuleBase1);
            this.Modules.Add(this.module3);
            this.Modules.Add(this.conditionalEditorStateWindowsFormsModule1);
            this.Modules.Add(this.fileAttachmentsWindowsFormsModule1);
            this.Modules.Add(this.htmlPropertyEditorWindowsFormsModule1);
            this.Modules.Add(this.pivotChartModuleBase1);
            this.Modules.Add(this.pivotChartWindowsFormsModule1);
            this.Modules.Add(this.printingWindowsFormsModule1);
            this.Modules.Add(this.reportsWindowsFormsModule1);
            this.Modules.Add(this._filterDataStoreWindowsFormsModule);
            this.Modules.Add(this.schedulerModuleBase1);
            this.Modules.Add(this.schedulerWindowsFormsModule1);
            this.Modules.Add(this.treeListEditorsModuleBase1);
            this.Modules.Add(this.treeListEditorsWindowsFormsModule1);
            this.Modules.Add(this.module7);
            this.Modules.Add(this.eXpandSystemWindowsFormsModule1);
            this.Modules.Add(this.modelArtifactStateWindowsFormsModule1);
            this.Modules.Add(this.modelDifferenceWindowsFormsModule1);
            this.Modules.Add(this.eXpandTreeListEditorsWin1);
            this.Modules.Add(this.eXpandViewVariantsWin1);
            this.Modules.Add(this.wizardUIWindowsFormsModule1);
            this.Modules.Add(this.ioWinModule1);
            this.Modules.Add(this.module4);
            this.Modules.Add(this.securityModule1);
            this.Modules.Add(this.worldCreatorModule1);
            this.Modules.Add(this.ioModule1);
            this.Security = this.securityComplex1;
            this.DatabaseVersionMismatch += new System.EventHandler<DevExpress.ExpressApp.DatabaseVersionMismatchEventArgs>(this.$safesolutionname$WindowsFormsApplication_DatabaseVersionMismatch);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion


        private DevExpress.ExpressApp.SystemModule.SystemModule module1;
        private DevExpress.ExpressApp.Win.SystemModule.SystemWindowsFormsModule module2;
        private $safesolutionname$.Module.$safesolutionname$Module module3;
        private $safesolutionname$.Module.Win.$safesolutionname$WindowsFormsModule module4;
        private DevExpress.ExpressApp.Validation.ValidationModule module5;
        private DevExpress.ExpressApp.Objects.BusinessClassLibraryCustomizationModule module6;
        private DevExpress.ExpressApp.Validation.Win.ValidationWindowsFormsModule module7;
        private DevExpress.ExpressApp.Security.SecurityModule securityModule1;
        private System.Data.SqlClient.SqlConnection sqlConnection1;
        private DevExpress.ExpressApp.AuditTrail.AuditTrailModule auditTrailModule1;
        private DevExpress.ExpressApp.CloneObject.CloneObjectModule cloneObjectModule1;
        private DevExpress.ExpressApp.ConditionalFormatting.ConditionalFormattingModule conditionalFormattingModule1;
        private DevExpress.ExpressApp.ViewVariantsModule.ViewVariantsModule viewVariantsModule1;
        private eXpand.ExpressApp.SystemModule.eXpandSystemModule eXpandSystemModule1;
        private eXpand.ExpressApp.Security.eXpandSecurityModule eXpandSecurityModule1;
        private eXpand.ExpressApp.Validation.eXpandValidationModule eXpandValidationModule1;
        private eXpand.ExpressApp.ModelArtifactState.ModelArtifactStateModule modelArtifactStateModule1;
        private eXpand.ExpressApp.ModelDifference.ModelDifferenceModule modelDifferenceModule1;
        private eXpand.ExpressApp.ViewVariants.eXpandViewVariantsModule eXpandViewVariantsModule1;
        private DevExpress.ExpressApp.ConditionalEditorState.ConditionalEditorStateModuleBase conditionalEditorStateModuleBase1;
        private eXpand.ExpressApp.WorldCreator.WorldCreatorModule worldCreatorModule1;
        private eXpand.ExpressApp.IO.IOModule ioModule1;
        private DevExpress.ExpressApp.ConditionalEditorState.Win.ConditionalEditorStateWindowsFormsModule conditionalEditorStateWindowsFormsModule1;
        private DevExpress.ExpressApp.FileAttachments.Win.FileAttachmentsWindowsFormsModule fileAttachmentsWindowsFormsModule1;
        private DevExpress.ExpressApp.HtmlPropertyEditor.Win.HtmlPropertyEditorWindowsFormsModule htmlPropertyEditorWindowsFormsModule1;
        private DevExpress.ExpressApp.PivotChart.PivotChartModuleBase pivotChartModuleBase1;
        private DevExpress.ExpressApp.PivotChart.Win.PivotChartWindowsFormsModule pivotChartWindowsFormsModule1;
        private DevExpress.ExpressApp.Printing.Win.PrintingWindowsFormsModule printingWindowsFormsModule1;
        private DevExpress.ExpressApp.Reports.Win.ReportsWindowsFormsModule reportsWindowsFormsModule1;
        FilterDataStoreWindowsFormsModule _filterDataStoreWindowsFormsModule;
        private DevExpress.ExpressApp.Scheduler.SchedulerModuleBase schedulerModuleBase1;
        private DevExpress.ExpressApp.Scheduler.Win.SchedulerWindowsFormsModule schedulerWindowsFormsModule1;
        private DevExpress.ExpressApp.TreeListEditors.TreeListEditorsModuleBase treeListEditorsModuleBase1;
        private DevExpress.ExpressApp.TreeListEditors.Win.TreeListEditorsWindowsFormsModule treeListEditorsWindowsFormsModule1;
        private eXpand.ExpressApp.Win.SystemModule.eXpandSystemWindowsFormsModule eXpandSystemWindowsFormsModule1;
        private eXpand.ExpressApp.ModelArtifactState.Win.ModelArtifactStateWindowsFormsModule modelArtifactStateWindowsFormsModule1;
        private eXpand.ExpressApp.ModelDifference.Win.ModelDifferenceWindowsFormsModule modelDifferenceWindowsFormsModule1;
        private eXpand.ExpressApp.TreeListEditors.Win.eXpandTreeListEditorsWin eXpandTreeListEditorsWin1;
        private eXpand.ExpressApp.ViewVariants.Win.eXpandViewVariantsWin eXpandViewVariantsWin1;
        private eXpand.ExpressApp.WizardUI.Win.WizardUIWindowsFormsModule wizardUIWindowsFormsModule1;
        private eXpand.ExpressApp.WorldCreator.Win.WorldCreatorWinModule worldCreatorWinModule1;
        private eXpand.ExpressApp.IO.Win.IOWinModule ioWinModule1;
        private DevExpress.ExpressApp.Security.SecurityComplex securityComplex1;
        private DevExpress.ExpressApp.Security.AuthenticationStandard authenticationStandard1;
    }
}
